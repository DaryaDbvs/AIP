package command;

import entity.Thermostat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SetTemperatureCommand implements Command {
    private static final Logger logger = LogManager.getLogger(SetTemperatureCommand.class);
    private Thermostat thermostat;
    private Double previousTemp;
    private double newTemp;
    private boolean executed = false;

    public SetTemperatureCommand(Thermostat thermostat, double newTemp) {
        this.thermostat = thermostat;
        this.newTemp = newTemp;
        logger.debug("SetTemperatureCommand created for {}: {}°C", thermostat.getName(), newTemp);
    }

    @Override
    public void execute() {
        logger.info("Executing SetTemperatureCommand for: {}", thermostat.getName());
        previousTemp = thermostat.getTemperature();
        thermostat.setTemperature(newTemp);
        executed = true;
        logger.info("{} temperature set to {}°C (was {}°C)",
                thermostat.getName(), newTemp, previousTemp);
    }

    @Override
    public void undo() {
        if (!executed) {
            logger.warn("Cannot undo: command was not executed yet for {}", thermostat.getName());
            return;
        }
        if (previousTemp == null) {
            logger.error("Cannot undo: previous temperature is null for {}", thermostat.getName());
            return;
        }
        logger.info("Undoing temperature change for: {}", thermostat.getName());
        thermostat.setTemperature(previousTemp);
        executed = false;
        logger.info("{} temperature restored to {}°C", thermostat.getName(), previousTemp);
    }
}