package command;

import entity.Device;
import state.OffState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TurnOffCommand implements Command {
    private static final Logger logger = LogManager.getLogger(TurnOffCommand.class);
    private Device device;

    public TurnOffCommand(Device device) {
        this.device = device;
        logger.debug("TurnOffCommand created for device: {}", device.getName());
    }

    @Override
    public void execute() {
        logger.info("Executing TurnOffCommand for: {}", device.getName());
        device.getState().off();
        device.setState(new OffState());
        logger.info("{} turned OFF successfully", device.getName());
    }

    @Override
    public void undo() {
        logger.info("Undoing TurnOffCommand for: {}", device.getName());
    }
}
