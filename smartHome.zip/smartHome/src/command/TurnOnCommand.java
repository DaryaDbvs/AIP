package command;

import entity.Device;
import state.OnState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TurnOnCommand implements Command {
    private static final Logger logger = LogManager.getLogger(TurnOnCommand.class);
    private Device device;

    public TurnOnCommand(Device device) {
        this.device = device;
        logger.debug("TurnOnCommand created for device: {}", device.getName());
    }

    @Override
    public void execute() {
        logger.info("Executing TurnOnCommand for: {}", device.getName());
        device.getState().on();
        device.setState(new OnState());
        logger.info("{} turned ON successfully", device.getName());
    }

    @Override
    public void undo() {
        logger.info("Undoing TurnOnCommand for: {}", device.getName());
    }
}