package mediator;

import command.Command;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.ArrayList;
import java.util.List;

public class Scenario {
    private static final Logger logger = LogManager.getLogger(Scenario.class);
    private String name;
    private List<Command> commands = new ArrayList<>();

    public Scenario(String name) {
        this.name = name;
        logger.info("Scenario created: {}", name);
    }

    public void addCommand(Command command) {
        commands.add(command);
        logger.debug("Command added to scenario '{}': {}", name, command.getClass().getSimpleName());
    }

    public void execute() {
        logger.info("Executing scenario: {} with {} commands", name, commands.size());
        commands.forEach(command -> {
            logger.debug("Executing command in scenario '{}'", name);
            command.execute();
        });
        logger.info("Scenario '{}' execution completed", name);
    }
}
