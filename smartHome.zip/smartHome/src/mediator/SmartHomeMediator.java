package mediator;


import entity.Device;
import command.Command;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.ArrayList;
import java.util.List;

public class SmartHomeMediator implements Mediator {
    private static final Logger logger = LogManager.getLogger(SmartHomeMediator.class);
    private List<Device> devices = new ArrayList<>();

    @Override
    public void registerDevice(Device device) {
        devices.add(device);
        logger.info("Device registered in Mediator: {} (Type: {}, ID: {})",
                device.getName(), device.getClass().getSimpleName(), device.getId());
    }

    @Override
    public void executeScenario(Command command) {
        logger.info("Executing scenario command through Mediator");
        command.execute();
        logger.info("Scenario command execution completed");
    }
}