package mediator;

import command.Command;
import entity.Device;

public interface Mediator {
    void registerDevice(Device device);
    void executeScenario(Command command);
}
