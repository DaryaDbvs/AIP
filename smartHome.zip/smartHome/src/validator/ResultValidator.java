package validator;


import entity.Device;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ResultValidator {
    private static final Logger logger = LogManager.getLogger(ResultValidator.class);

    public ValidationResult validateDeviceState(Device device) {
        if (device.getState() == null) {
            logger.error("Device state validation failed for {}: state is null", device.getName());
            return new ValidationResult(false, "Device has no state");
        }
        logger.debug("Device state validation passed for {}: state = {}",
                device.getName(), device.getState().getStateName());
        return new ValidationResult(true, null);
    }
}