package validator;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DeviceDataValidator {
    private static final Logger logger = LogManager.getLogger(DeviceDataValidator.class);

    public ValidationResult validateLight(String name, String brightnessStr) {
        if (name == null || name.trim().isEmpty()) {
            logger.warn("Light validation failed: empty name");
            return new ValidationResult(false, "Invalid light name");
        }
        try {
            int brightness = Integer.parseInt(brightnessStr);
            if (brightness < 0 || brightness > 100) {
                logger.warn("Light validation failed for {}: brightness {} out of range 0-100",
                        name, brightness);
                return new ValidationResult(false, "Brightness must be 0-100");
            }
            logger.debug("Light validation passed: {} - {}%", name, brightness);
            return new ValidationResult(true, null);
        } catch (NumberFormatException e) {
            logger.warn("Light validation failed for {}: invalid brightness format '{}'",
                    name, brightnessStr, e);
            return new ValidationResult(false, "Invalid brightness number");
        }
    }

    public ValidationResult validateThermostat(String name, String tempStr) {
        if (name == null || name.trim().isEmpty()) {
            logger.warn("Thermostat validation failed: empty name");
            return new ValidationResult(false, "Invalid thermostat name");
        }
        try {
            double temp = Double.parseDouble(tempStr);
            if (temp < 0 || temp > 40) {
                logger.warn("Thermostat validation failed for {}: temperature {} out of range 0-40°C",
                        name, temp);
                return new ValidationResult(false, "Temperature must be 0-40°C");
            }
            logger.debug("Thermostat validation passed: {} - {}°C", name, temp);
            return new ValidationResult(true, null);
        } catch (NumberFormatException e) {
            logger.warn("Thermostat validation failed for {}: invalid temperature format '{}'",
                    name, tempStr, e);
            return new ValidationResult(false, "Invalid temperature number");
        }
    }

    public ValidationResult validateLock(String name, String lockedStr) {
        if (name == null || name.trim().isEmpty()) {
            logger.warn("Lock validation failed: empty name");
            return new ValidationResult(false, "Invalid lock name");
        }
        if (!"true".equalsIgnoreCase(lockedStr) && !"false".equalsIgnoreCase(lockedStr)) {
            logger.warn("Lock validation failed for {}: invalid locked value '{}' (must be true/false)",
                    name, lockedStr);
            return new ValidationResult(false, "Locked must be true/false");
        }
        logger.debug("Lock validation passed: {} - {}", name, lockedStr);
        return new ValidationResult(true, null);
    }
}