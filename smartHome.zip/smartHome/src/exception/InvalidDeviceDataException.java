package exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class InvalidDeviceDataException extends Exception {
    private static final Logger logger = LogManager.getLogger(InvalidDeviceDataException.class);

    public InvalidDeviceDataException(String message) {
        super(message);
        logger.error("InvalidDeviceDataException: {}", message);
    }

    public InvalidDeviceDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidDeviceDataException(Throwable cause) {
        super(cause);
    }

    public InvalidDeviceDataException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public InvalidDeviceDataException() {
    }
}
