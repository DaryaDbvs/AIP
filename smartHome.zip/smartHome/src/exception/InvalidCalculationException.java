package exception;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class InvalidCalculationException extends Exception {
    private static final Logger logger = LogManager.getLogger(InvalidCalculationException.class);

    public InvalidCalculationException(String message) {
        super(message);
        logger.error("InvalidCalculationException: {}", message);
    }

    public InvalidCalculationException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidCalculationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public InvalidCalculationException(Throwable cause) {
        super(cause);
    }

    public InvalidCalculationException() {
    }
}