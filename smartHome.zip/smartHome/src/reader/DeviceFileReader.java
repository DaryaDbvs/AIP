package reader;

import entity.Device;
import entity.Light;
import entity.Thermostat;
import entity.Lock;
import validator.DeviceDataValidator;
import validator.ValidationResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class DeviceFileReader {
    private static final Logger logger = LogManager.getLogger(DeviceFileReader.class);
    private DeviceDataValidator validator = new DeviceDataValidator();

    public List<Device> readDevices(String filePath) throws IOException {
        List<Device> devices = new ArrayList<>();
        Path path = Paths.get(filePath);

        logger.info("Starting to read devices from file: {}", filePath);

        if (path.getParent() != null) {
            logger.error("File access denied - file outside current directory: {}", filePath);
            throw new IllegalArgumentException("File must be in current directory only");
        }

        if (!Files.exists(path)) {
            logger.error("File not found: {}", filePath);
            throw new IOException("File not found: " + filePath);
        }

        try (Stream<String> lines = Files.lines(path)) {
            long[] lineCounter = {0};
            lines.forEach(line -> {
                lineCounter[0]++;
                logger.debug("Processing line {}: {}", lineCounter[0], line);

                String[] parts = line.split(",");
                if (parts.length < 3) {
                    logger.warn("Line {} skipped: insufficient data (expected 3 parts, got {}) - {}",
                            lineCounter[0], parts.length, line);
                    return;
                }

                String type = parts[0].trim();
                String name = parts[1].trim();
                String param = parts[2].trim();

                switch (type.toLowerCase()) {
                    case "light":
                        ValidationResult lightRes = validator.validateLight(name, param);
                        if (lightRes.isValid()) {
                            Light light = new Light(name, Integer.parseInt(param));
                            devices.add(light);
                            logger.info("Light successfully created from line {}: {} (brightness: {}%)",
                                    lineCounter[0], name, param);
                        } else {
                            logger.warn("Line {} skipped - Light validation failed: {} - {}",
                                    lineCounter[0], lightRes.getErrorMessage(), line);
                        }
                        break;
                    case "thermostat":
                        ValidationResult thermoRes = validator.validateThermostat(name, param);
                        if (thermoRes.isValid()) {
                            Thermostat thermostat = new Thermostat(name, Double.parseDouble(param));
                            devices.add(thermostat);
                            logger.info("Thermostat successfully created from line {}: {} (temperature: {}°C)",
                                    lineCounter[0], name, param);
                        } else {
                            logger.warn("Line {} skipped - Thermostat validation failed: {} - {}",
                                    lineCounter[0], thermoRes.getErrorMessage(), line);
                        }
                        break;
                    case "lock":
                        ValidationResult lockRes = validator.validateLock(name, param);
                        if (lockRes.isValid()) {
                            Lock lock = new Lock(name, Boolean.parseBoolean(param));
                            devices.add(lock);
                            logger.info("Lock successfully created from line {}: {} (locked: {})",
                                    lineCounter[0], name, param);
                        } else {
                            logger.warn("Line {} skipped - Lock validation failed: {} - {}",
                                    lineCounter[0], lockRes.getErrorMessage(), line);
                        }
                        break;
                    default:
                        logger.warn("Line {} skipped - Unknown device type '{}' - {}",
                                lineCounter[0], type, line);
                }
            });
        } catch (IOException e) {
            logger.error("IO error while reading file: {}", filePath, e);
            throw e;
        }

        logger.info("File reading completed. Successfully created {} devices out of {} lines",
                devices.size(), Files.lines(path).count());

        return devices;
    }
}
