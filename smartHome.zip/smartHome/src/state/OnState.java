package state;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class OnState implements DeviceState {
    private static final Logger logger = LogManager.getLogger(OnState.class);

    @Override
    public void on() {
        logger.warn("Already ON state");
    }

    @Override
    public void off() {
        logger.info("Switching OFF");
    }

    @Override
    public void error() {
        logger.error("Entering ERROR state");
    }

    @Override
    public void maintenance() {
        logger.info("Entering MAINTENANCE state");
    }

    @Override
    public String getStateName() { return "ON"; }
}