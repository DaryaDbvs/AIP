package state;

public interface DeviceState {
    void on();
    void off();
    void error();
    void maintenance();
    String getStateName();
}
