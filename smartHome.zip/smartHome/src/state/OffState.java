package state;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class OffState implements DeviceState {
    private static final Logger logger = LogManager.getLogger(OffState.class);

    @Override
    public void on() {
        logger.info("Switching ON");
    }

    @Override
    public void off() {
        logger.warn("Already OFF state");
    }

    @Override
    public void error() {
        logger.error("Entering ERROR state");
    }

    @Override
    public void maintenance() {
        logger.info("Entering MAINTENANCE state");
    }

    @Override
    public String getStateName() { return "OFF"; }
}