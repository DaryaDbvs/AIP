package state;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ErrorState implements DeviceState {
    private static final Logger logger = LogManager.getLogger(ErrorState.class);

    @Override
    public void on() {
        logger.error("Cannot ON - device in ERROR");
    }

    @Override
    public void off() {
        logger.error("Cannot OFF - device in ERROR");
    }

    @Override
    public void error() {
        logger.warn("Already in ERROR state");
    }

    @Override
    public void maintenance() {
        logger.info("Moving from ERROR to MAINTENANCE");
    }

    @Override
    public String getStateName() { return "ERROR"; }
}
