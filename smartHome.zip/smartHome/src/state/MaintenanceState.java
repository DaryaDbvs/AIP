package state;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MaintenanceState implements DeviceState {
    private static final Logger logger = LogManager.getLogger(MaintenanceState.class);

    @Override
    public void on() {
        logger.warn("Cannot ON - device in MAINTENANCE");
    }

    @Override
    public void off() {
        logger.warn("Cannot OFF - device in MAINTENANCE");
    }

    @Override
    public void error() {
        logger.error("Moving from MAINTENANCE to ERROR");
    }

    @Override
    public void maintenance() {
        logger.warn("Already in MAINTENANCE state");
    }

    @Override
    public String getStateName() { return "MAINTENANCE"; }
}
