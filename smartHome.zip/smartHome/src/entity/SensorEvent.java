package entity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SensorEvent {
    private static final Logger logger = LogManager.getLogger(SensorEvent.class);
    private final String sensorId;
    private final String eventType;
    private final String value;

    public SensorEvent(String sensorId, String eventType, String value) {
        this.sensorId = sensorId;
        this.eventType = eventType;
        this.value = value;
        logger.debug("SensorEvent created - Sensor: {}, Type: {}, Value: {}", sensorId, eventType, value);
    }

    public String getSensorId() { return sensorId; }
    public String getEventType() { return eventType; }
    public String getValue() { return value; }

    @Override
    public String toString() {
        return String.format("SensorEvent{sensorId='%s', eventType='%s', value='%s'}",
                sensorId, eventType, value);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        SensorEvent that = (SensorEvent) obj;
        return sensorId.equals(that.sensorId) && eventType.equals(that.eventType);
    }

    @Override
    public int hashCode() {
        return 31 * sensorId.hashCode() + eventType.hashCode();
    }
}