package entity;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Light extends Device {
    private static final Logger logger = LogManager.getLogger(Light.class);
    private int brightness;

    public Light(String name, int brightness) {
        super(name);
        this.brightness = brightness;
        logger.info("Light created - Name: {}, Brightness: {}%", name, brightness);
    }

    public int getBrightness() { return brightness; }

    public void setBrightness(int brightness) {
        this.brightness = brightness;
        logger.debug("Light {} brightness set to {}%", getName(), brightness);
    }
}
