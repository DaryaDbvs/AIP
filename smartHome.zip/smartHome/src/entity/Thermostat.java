package entity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Thermostat extends Device {
    private static final Logger logger = LogManager.getLogger(Thermostat.class);
    private double temperature;

    public Thermostat(String name, double temperature) {
        super(name);
        this.temperature = temperature;
        logger.info("Thermostat created - Name: {}, Temperature: {}°C", name, temperature);
    }

    public double getTemperature() { return temperature; }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        logger.debug("Thermostat {} temperature set to {}°C", getName(), temperature);
    }
}
