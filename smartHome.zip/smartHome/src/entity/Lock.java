package entity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Lock extends Device {
    private static final Logger logger = LogManager.getLogger(Lock.class);
    private boolean locked;

    public Lock(String name, boolean locked) {
        super(name);
        this.locked = locked;
        logger.info("Lock created - Name: {}, Locked: {}", name, locked);
    }

    public boolean isLocked() { return locked; }

    public void setLocked(boolean locked) {
        this.locked = locked;
        logger.debug("Lock {} set to: {}", getName(), locked ? "LOCKED" : "UNLOCKED");
    }
}
