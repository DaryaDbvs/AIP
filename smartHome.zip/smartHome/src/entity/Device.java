package entity;

import state.DeviceState;
import state.OffState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.UUID;

public abstract class Device {
    private static final Logger logger = LogManager.getLogger(Device.class);
    private final String id;
    private String name;
    protected DeviceState state;

    public Device(String name) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.state = new OffState();
        logger.debug("Device created: {} with id: {}", name, id);
    }

    public String getId() { return id; }
    public String getName() { return name; }

    public void setName(String name) {
        this.name = name;
        logger.debug("Device renamed to: {}", name);
    }

    public DeviceState getState() { return state; }

    public void setState(DeviceState state) {
        if (state == null) {
            logger.warn("Attempted to set null state for device: {}", name);
            throw new IllegalArgumentException("Device state cannot be null");
        }
        this.state = state;
        logger.debug("Device {} state changed to: {}", name, state.getStateName());
    }

    @Override
    public String toString() {
        String stateName = (state != null) ? state.getStateName() : "UNKNOWN";
        return String.format("%s{id='%s', name='%s', state=%s}",
                getClass().getSimpleName(), id, name, stateName);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Device device = (Device) obj;
        return id.equals(device.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}