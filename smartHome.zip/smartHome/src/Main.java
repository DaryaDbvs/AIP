import entity.*;
import command.*;
import mediator.SmartHomeMediator;
import observer.LightController;
import observer.MotionSensor;
import reader.DeviceFileReader;
import strategy.AggressiveSavingStrategy;
import validator.ResultValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        logger.info("=== Smart Home System Starting ===");

        try {
            DeviceFileReader reader = new DeviceFileReader();
            List<Device> devices = reader.readDevices("devices.txt");

            logger.info("Successfully loaded {} valid devices", devices.size());
            System.out.println("\n=== Valid devices loaded ===");
            devices.forEach(System.out::println);

            SmartHomeMediator mediator = new SmartHomeMediator();
            devices.forEach(mediator::registerDevice);

            if (!devices.isEmpty() && devices.get(0) instanceof Light) {
                logger.info("Executing TurnOnCommand for first device");
                Command turnOn = new TurnOnCommand(devices.get(0));
                mediator.executeScenario(turnOn);
            } else {
                logger.warn("No Light device found for TurnOnCommand demonstration");
            }

            if (devices.stream().anyMatch(d -> d instanceof Light)) {
                Light light = (Light) devices.stream().filter(d -> d instanceof Light).findFirst().get();
                LightController controller = new LightController(light);
                MotionSensor sensor = new MotionSensor("SENSOR_001");
                sensor.attach(controller);

                logger.info("Simulating motion detection");
                sensor.detectMotion(true);
            } else {
                logger.warn("No Light device found for Observer demonstration");
            }

            System.out.println("\n=== Applying aggressive energy saving ===");
            AggressiveSavingStrategy strategy = new AggressiveSavingStrategy();
            strategy.apply(devices);

            ResultValidator resultValidator = new ResultValidator();
            devices.forEach(d -> {
                var res = resultValidator.validateDeviceState(d);
                if (!res.isValid()) {
                    logger.error("Validation failed for device {}: {}", d.getName(), res.getErrorMessage());
                    System.out.println("Validation failed for " + d.getName() + ": " + res.getErrorMessage());
                }
            });

            logger.info("=== Smart Home System Shutdown Normally ===");

        } catch (Exception e) {
            logger.error("Fatal error in Smart Home System", e);
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}