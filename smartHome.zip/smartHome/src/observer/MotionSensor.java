package observer;


import entity.SensorEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MotionSensor extends Subject {
    private static final Logger logger = LogManager.getLogger(MotionSensor.class);
    private String id;
    private boolean motionDetected;

    public MotionSensor(String id) {
        this.id = id;
        logger.info("MotionSensor created with ID: {}", id);
    }

    public void detectMotion(boolean motion) {
        this.motionDetected = motion;
        if (motion) {
            logger.info("Motion DETECTED by sensor: {}", id);
            notifyObservers(new SensorEvent(id, "MOTION", "DETECTED"));
        } else {
            logger.debug("Motion stopped on sensor: {}", id);
        }
    }
}