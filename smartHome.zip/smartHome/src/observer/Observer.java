package observer;

import entity.SensorEvent;

public interface Observer {
    void update(SensorEvent event);
}
