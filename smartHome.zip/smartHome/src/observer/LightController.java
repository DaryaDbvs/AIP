package observer;

import entity.Light;
import entity.SensorEvent;
import state.OffState;
import state.OnState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LightController implements Observer {
    private static final Logger logger = LogManager.getLogger(LightController.class);
    private Light light;
    private boolean autoOffEnabled = true;

    public LightController(Light light) {
        this.light = light;
        logger.info("LightController created for: {}", light.getName());
    }

    public LightController(Light light, boolean autoOffEnabled) {
        this.light = light;
        this.autoOffEnabled = autoOffEnabled;
        logger.info("LightController created for: {} (auto-off: {})", light.getName(), autoOffEnabled);
    }

    @Override
    public void update(SensorEvent event) {
        logger.debug("LightController received event: {} from sensor: {}",
                event.getEventType(), event.getSensorId());

        if ("MOTION".equals(event.getEventType())) {
            if ("DETECTED".equals(event.getValue())) {
                light.setState(new OnState());
                logger.info("{} turned ON by motion sensor {}", light.getName(), event.getSensorId());
            } else if ("STOPPED".equals(event.getValue()) && autoOffEnabled) {
                light.setState(new OffState());
                logger.info("{} turned OFF by motion sensor {} (no motion detected)",
                        light.getName(), event.getSensorId());
            }
        }
    }

    public void setAutoOffEnabled(boolean enabled) {
        this.autoOffEnabled = enabled;
        logger.debug("Auto-off for {} set to: {}", light.getName(), enabled);
    }
}