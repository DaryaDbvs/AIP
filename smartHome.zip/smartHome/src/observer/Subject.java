package observer;

import entity.SensorEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.ArrayList;
import java.util.List;

public abstract class Subject {
    private static final Logger logger = LogManager.getLogger(Subject.class);
    private List<Observer> observers = new ArrayList<>();

    public void attach(Observer observer) {
        observers.add(observer);
        logger.debug("Observer attached: {}", observer.getClass().getSimpleName());
    }

    public void detach(Observer observer) {
        observers.remove(observer);
        logger.debug("Observer detached: {}", observer.getClass().getSimpleName());
    }

    protected void notifyObservers(SensorEvent event) {
        logger.debug("Notifying {} observers about event: {}", observers.size(), event.getEventType());
        observers.forEach(o -> o.update(event));
    }
}
