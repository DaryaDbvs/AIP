package strategy;


import entity.Device;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

public class NoSavingStrategy implements EnergySavingStrategy {
    private static final Logger logger = LogManager.getLogger(NoSavingStrategy.class);

    @Override
    public void apply(List<Device> devices) {
        logger.info("NO energy saving strategy applied - all devices keep current settings");
    }
}
