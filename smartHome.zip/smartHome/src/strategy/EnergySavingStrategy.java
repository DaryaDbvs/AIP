package strategy;

import entity.Device;

import java.util.List;

public interface EnergySavingStrategy {
    void apply(List<Device> devices);
}
