package strategy;


import entity.Device;
import entity.Light;
import entity.Thermostat;
import state.OffState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

public class AggressiveSavingStrategy implements EnergySavingStrategy {
    private static final Logger logger = LogManager.getLogger(AggressiveSavingStrategy.class);

    @Override
    public void apply(List<Device> devices) {
        logger.info("Applying AGGRESSIVE energy saving strategy to {} devices", devices.size());

        devices.forEach(device -> {
            if (device instanceof Light) {
                device.setState(new OffState());
                logger.info("{} turned OFF (aggressive saving)", device.getName());
            } else if (device instanceof Thermostat) {
                Thermostat thermostat = (Thermostat) device;
                double oldTemp = thermostat.getTemperature();
                thermostat.setTemperature(15.0);
                logger.info("{} temperature reduced from {}°C to 15°C (aggressive saving)",
                        device.getName(), oldTemp);
            }
        });

        logger.info("Aggressive energy saving strategy applied");
    }
}