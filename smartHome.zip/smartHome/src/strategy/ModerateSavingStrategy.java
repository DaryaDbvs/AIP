package strategy;

import entity.Device;
import entity.Light;
import entity.Thermostat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

public class ModerateSavingStrategy implements EnergySavingStrategy {
    private static final Logger logger = LogManager.getLogger(ModerateSavingStrategy.class);

    @Override
    public void apply(List<Device> devices) {
        logger.info("Applying MODERATE energy saving strategy to {} devices", devices.size());

        devices.forEach(device -> {
            if (device instanceof Light) {
                Light light = (Light) device;
                int oldBrightness = light.getBrightness();
                light.setBrightness(30);
                logger.info("{} brightness reduced from {}% to 30% (moderate saving)",
                        device.getName(), oldBrightness);
            } else if (device instanceof Thermostat) {
                Thermostat thermostat = (Thermostat) device;
                double oldTemp = thermostat.getTemperature();
                thermostat.setTemperature(18.0);
                logger.info("{} temperature reduced from {}°C to 18°C (moderate saving)",
                        device.getName(), oldTemp);
            }
        });

        logger.info("Moderate energy saving strategy applied");
    }
}