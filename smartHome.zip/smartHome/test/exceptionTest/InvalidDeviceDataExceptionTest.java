package exceptionTest;


import exception.InvalidDeviceDataException;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class InvalidDeviceDataExceptionTest {

    @Test
    public void testExceptionCreation() {
        String message = "Invalid device data";
        InvalidDeviceDataException exception = new InvalidDeviceDataException(message);
        assertEquals(exception.getMessage(), message);
    }

    @Test
    public void testExceptionWithEmptyMessage() {
        InvalidDeviceDataException exception = new InvalidDeviceDataException("");
        assertEquals(exception.getMessage(), "");
    }

    @Test
    public void testExceptionIsInstanceOfException() {
        InvalidDeviceDataException exception = new InvalidDeviceDataException("test");
        assertTrue(exception instanceof Exception);
    }
}