package exceptionTest;


import exception.InvalidCalculationException;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class InvalidCalculationExceptionTest {

    @Test
    public void testExceptionCreation() {
        String message = "Invalid calculation result";
        InvalidCalculationException exception = new InvalidCalculationException(message);
        assertEquals(exception.getMessage(), message);
    }

    @Test
    public void testExceptionWithEmptyMessage() {
        InvalidCalculationException exception = new InvalidCalculationException("");
        assertEquals(exception.getMessage(), "");
    }

    @Test
    public void testExceptionIsInstanceOfException() {
        InvalidCalculationException exception = new InvalidCalculationException("test");
        assertTrue(exception instanceof Exception);
    }
}