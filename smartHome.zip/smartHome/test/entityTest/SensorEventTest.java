package entityTest;

import entity.SensorEvent;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class SensorEventTest {

    private SensorEvent event;

    @BeforeMethod
    public void setUp() {
        event = new SensorEvent("SENSOR_001", "MOTION", "DETECTED");
    }

    @Test
    public void testSensorEventCreation() {
        assertEquals(event.getSensorId(), "SENSOR_001");
        assertEquals(event.getEventType(), "MOTION");
        assertEquals(event.getValue(), "DETECTED");
    }

    @Test
    public void testToString() {
        String toString = event.toString();
        assertTrue(toString.contains("SENSOR_001"));
        assertTrue(toString.contains("MOTION"));
        assertTrue(toString.contains("DETECTED"));
    }

    @Test
    public void testEqualsSameSensorAndType() {
        SensorEvent event2 = new SensorEvent("SENSOR_001", "MOTION", "DIFFERENT_VALUE");
        assertEquals(event, event2);
    }

    @Test
    public void testEqualsDifferentSensor() {
        SensorEvent event2 = new SensorEvent("SENSOR_002", "MOTION", "DETECTED");
        assertNotEquals(event, event2);
    }

    @Test
    public void testEqualsDifferentType() {
        SensorEvent event2 = new SensorEvent("SENSOR_001", "TEMPERATURE", "DETECTED");
        assertNotEquals(event, event2);
    }

    @Test
    public void testHashCode() {
        SensorEvent event2 = new SensorEvent("SENSOR_001", "MOTION", "DIFFERENT");
        assertEquals(event.hashCode(), event2.hashCode());
    }

    @Test
    public void testEqualsNull() {
        assertNotEquals(event, null);
    }
}