package entityTest;

import entity.Lock;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class LockTest {

    private Lock lock;

    @BeforeMethod
    public void setUp() {
        lock = new Lock("Front Door", true);
    }

    @Test
    public void testLockCreation() {
        assertEquals(lock.getName(), "Front Door");
        assertTrue(lock.isLocked());
        assertNotNull(lock.getId());
    }

    @Test
    public void testSetLocked() {
        lock.setLocked(false);
        assertFalse(lock.isLocked());

        lock.setLocked(true);
        assertTrue(lock.isLocked());
    }

    @Test
    public void testToString() {
        String toString = lock.toString();
        assertTrue(toString.contains("Lock"));
        assertTrue(toString.contains("Front Door"));
    }
}