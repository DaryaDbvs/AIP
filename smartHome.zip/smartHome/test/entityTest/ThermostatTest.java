package entityTest;

import entity.Thermostat;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class ThermostatTest {

    private Thermostat thermostat;

    @BeforeMethod
    public void setUp() {
        thermostat = new Thermostat("Main Thermo", 22.5);
    }

    @Test
    public void testThermostatCreation() {
        assertEquals(thermostat.getName(), "Main Thermo");
        assertEquals(thermostat.getTemperature(), 22.5);
        assertNotNull(thermostat.getId());
    }

    @Test
    public void testSetTemperature() {
        thermostat.setTemperature(18.0);
        assertEquals(thermostat.getTemperature(), 18.0);
    }

    @Test
    public void testTemperatureBoundaryValues() {
        thermostat.setTemperature(0.0);
        assertEquals(thermostat.getTemperature(), 0.0);

        thermostat.setTemperature(40.0);
        assertEquals(thermostat.getTemperature(), 40.0);

        thermostat.setTemperature(-5.0);
        assertEquals(thermostat.getTemperature(), -5.0);
    }

    @Test
    public void testToString() {
        String toString = thermostat.toString();
        assertTrue(toString.contains("Thermostat"));
        assertTrue(toString.contains("Main Thermo"));
    }
}