package entityTest;


import entity.Device;
import state.OffState;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class DeviceTest {

    private Device device;

    @BeforeMethod
    public void setUp() {
        device = new TestDevice("Test Device");
    }

    @Test
    public void testDeviceCreation() {
        assertNotNull(device.getId());
        assertNotNull(device.getName());
        assertEquals(device.getName(), "Test Device");
        assertNotNull(device.getState());
        assertTrue(device.getState() instanceof OffState);
    }

    @Test
    public void testSetName() {
        device.setName("New Name");
        assertEquals(device.getName(), "New Name");
    }

    @Test
    public void testSetState() {
        device.setState(new OnState());
        assertTrue(device.getState() instanceof OnState);
    }

    @Test
    public void testToString() {
        String toString = device.toString();
        assertTrue(toString.contains("TestDevice"));
        assertTrue(toString.contains(device.getId()));
        assertTrue(toString.contains(device.getName()));
    }

    @Test
    public void testEqualsSameObject() {
        assertEquals(device, device);
    }

    @Test
    public void testEqualsDifferentObjectsSameId() {
        TestDevice device2 = new TestDevice("Different Name");
        // IDs are different because UUID creates unique IDs
        assertNotEquals(device, device2);
    }

    @Test
    public void testHashCode() {
        TestDevice device2 = new TestDevice("Test Device");
        assertNotEquals(device.hashCode(), device2.hashCode());
    }

    @Test
    public void testEqualsNull() {
        assertNotEquals(device, null);
    }

    @Test
    public void testEqualsDifferentClass() {
        assertNotEquals(device, "String");
    }

    // Helper class for testing abstract Device
    private static class TestDevice extends Device {
        public TestDevice(String name) {
            super(name);
        }
    }
}
