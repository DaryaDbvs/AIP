package entityTest;

import entity.Light;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class LightTest {

    private Light light;

    @BeforeMethod
    public void setUp() {
        light = new Light("Living Room", 75);
    }

    @Test
    public void testLightCreation() {
        assertEquals(light.getName(), "Living Room");
        assertEquals(light.getBrightness(), 75);
        assertNotNull(light.getId());
    }

    @Test
    public void testSetBrightness() {
        light.setBrightness(50);
        assertEquals(light.getBrightness(), 50);
    }

    @Test
    public void testBrightnessBoundaryValues() {
        light.setBrightness(0);
        assertEquals(light.getBrightness(), 0);

        light.setBrightness(100);
        assertEquals(light.getBrightness(), 100);
    }

    @Test
    public void testToString() {
        String toString = light.toString();
        assertTrue(toString.contains("Light"));
        assertTrue(toString.contains("Living Room"));
    }

    @Test
    public void testEquals() {
        Light light2 = new Light("Living Room", 75);
        assertNotEquals(light, light2); // Different IDs
    }
}
