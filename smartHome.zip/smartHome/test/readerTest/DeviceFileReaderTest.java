package readerTest;


import entity.Device;
import entity.Light;
import entity.Thermostat;
import entity.Lock;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import reader.DeviceFileReader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import static org.testng.Assert.*;

public class DeviceFileReaderTest {

    private DeviceFileReader reader;
    private Path testFile;

    @BeforeMethod
    public void setUp() throws IOException {
        reader = new DeviceFileReader();
        testFile = Paths.get("test_devices.txt");
    }

    @Test
    public void testReadValidDevices() throws IOException {
        String content = "light, Living Room, 80\n" +
                "thermostat, Main Thermo, 22.5\n" +
                "lock, Front Door, true\n";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");

        assertEquals(devices.size(), 3);
        assertTrue(devices.get(0) instanceof Light);
        assertTrue(devices.get(1) instanceof Thermostat);
        assertTrue(devices.get(2) instanceof Lock);

        Files.deleteIfExists(testFile);
    }

    @Test
    public void testReadWithInvalidData() throws IOException {
        String content = "light, Living Room, 80\n" +
                "light, Bedroom, -10\n" +
                "thermostat, Main Thermo, 22.5\n" +
                "lock, Front Door, maybe\n" +
                "invalid, Something, 123\n";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");

        // Only valid devices should be created
        assertEquals(devices.size(), 2);
        assertTrue(devices.get(0) instanceof Light);
        assertEquals(((Light) devices.get(0)).getBrightness(), 80);
        assertTrue(devices.get(1) instanceof Thermostat);

        Files.deleteIfExists(testFile);
    }

    @Test
    public void testReadEmptyFile() throws IOException {
        String content = "";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");
        assertEquals(devices.size(), 0);

        Files.deleteIfExists(testFile);
    }

    @Test
    public void testReadFileWithInsufficientData() throws IOException {
        String content = "light, Living Room\n" +
                "thermostat\n" +
                "lock, Front Door, true, extra\n";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");
        assertEquals(devices.size(), 1);
        assertTrue(devices.get(0) instanceof Lock);

        Files.deleteIfExists(testFile);
    }

    @Test
    public void testReadFileWithMixedValidInvalid() throws IOException {
        String content = "light, Living Room, 80\n" +
                "light, Bedroom, 150\n" +
                "thermostat, Main Thermo, 22.5\n" +
                "thermostat, Broken, 50\n" +
                "lock, Front Door, true\n" +
                "lock, Back Door, false\n";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");

        // Valid: LivingRoom light (80), Main Thermo (22.5), Front Door (true), Back Door (false)
        // Invalid: Bedroom light (150), Broken thermo (50)
        assertEquals(devices.size(), 4);

        Files.deleteIfExists(testFile);
    }

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void testReadFileOutsideDirectory() throws IOException {
        reader.readDevices("../outside.txt");
    }

    @Test(expectedExceptions = IOException.class)
    public void testReadNonExistentFile() throws IOException {
        reader.readDevices("nonexistent.txt");
    }

    @Test
    public void testReadWithDifferentCaseDeviceTypes() throws IOException {
        String content = "LIGHT, Living Room, 80\n" +
                "THERMOSTAT, Main Thermo, 22.5\n" +
                "LOCK, Front Door, true\n";
        Files.write(testFile, content.getBytes());

        List<Device> devices = reader.readDevices("test_devices.txt");

        assertEquals(devices.size(), 3);

        Files.deleteIfExists(testFile);
    }
}