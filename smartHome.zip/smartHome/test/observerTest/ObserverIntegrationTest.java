package observerTest;

import entity.Light;
import observer.LightController;
import observer.MotionSensor;
import state.OnState;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class ObserverIntegrationTest {

    @Test
    public void testFullObserverChain() {
        Light light = new Light("Hallway Light", 60);
        LightController controller = new LightController(light);
        MotionSensor sensor = new MotionSensor("HALLWAY_SENSOR");

        sensor.attach(controller);

        // Motion detected
        sensor.detectMotion(true);
        assertTrue(light.getState() instanceof OnState);

        // No motion
        sensor.detectMotion(false);
        // Light stays on (no auto-off in this implementation)
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testMultipleSensorsOneLight() {
        Light light = new Light("Central Light", 70);
        LightController controller = new LightController(light);

        MotionSensor sensor1 = new MotionSensor("SENSOR_1");
        MotionSensor sensor2 = new MotionSensor("SENSOR_2");

        sensor1.attach(controller);
        sensor2.attach(controller);

        sensor1.detectMotion(true);
        assertTrue(light.getState() instanceof OnState);

        // Reset light to off for next test
        light.setState(new state.OffState());

        sensor2.detectMotion(true);
        assertTrue(light.getState() instanceof OnState);
    }
}