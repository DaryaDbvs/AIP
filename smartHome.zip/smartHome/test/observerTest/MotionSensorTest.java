package observerTest;

import entity.SensorEvent;
import observer.MotionSensor;

import observer.Observer;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class MotionSensorTest {

    private MotionSensor sensor;
    private TestObserver testObserver;

    @BeforeMethod
    public void setUp() {
        sensor = new MotionSensor("TEST_SENSOR_001");
        testObserver = new TestObserver();
    }

    @Test
    public void testAttachObserver() {
        sensor.attach(testObserver);
        sensor.detectMotion(true);
        assertTrue(testObserver.wasNotified);
        assertNotNull(testObserver.lastEvent);
        assertEquals(testObserver.lastEvent.getSensorId(), "TEST_SENSOR_001");
        assertEquals(testObserver.lastEvent.getEventType(), "MOTION");
        assertEquals(testObserver.lastEvent.getValue(), "DETECTED");
    }

    @Test
    public void testDetectMotionTrue() {
        sensor.attach(testObserver);
        sensor.detectMotion(true);
        assertTrue(testObserver.wasNotified);
    }

    @Test
    public void testDetectMotionFalse() {
        sensor.attach(testObserver);
        sensor.detectMotion(false);
        assertFalse(testObserver.wasNotified);
    }

    @Test
    public void testDetachObserver() {
        sensor.attach(testObserver);
        sensor.detach(testObserver);
        sensor.detectMotion(true);
        assertFalse(testObserver.wasNotified);
    }

    @Test
    public void testMultipleObservers() {
        TestObserver observer2 = new TestObserver();
        sensor.attach(testObserver);
        sensor.attach(observer2);
        sensor.detectMotion(true);

        assertTrue(testObserver.wasNotified);
        assertTrue(observer2.wasNotified);
    }

    @Test
    public void testNoObservers() {
        sensor.detectMotion(true);
        // Should not throw any exception
    }

    // Helper class for testing
    private static class TestObserver implements Observer {
        boolean wasNotified = false;
        SensorEvent lastEvent = null;

        @Override
        public void update(SensorEvent event) {
            wasNotified = true;
            lastEvent = event;
        }
    }
}