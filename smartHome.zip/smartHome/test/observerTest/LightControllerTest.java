package observerTest;


import entity.Light;
import entity.SensorEvent;
import observer.LightController;
import state.OnState;
import state.OffState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class LightControllerTest {

    private Light light;
    private LightController controller;

    @BeforeMethod
    public void setUp() {
        light = new Light("Test Light", 50);
        controller = new LightController(light);
    }

    @Test
    public void testUpdateWithMotionDetected() {
        SensorEvent event = new SensorEvent("SENSOR_001", "MOTION", "DETECTED");
        controller.update(event);
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testUpdateWithMotionNotDetected() {
        SensorEvent event = new SensorEvent("SENSOR_001", "MOTION", "STOPPED");
        controller.update(event);
        assertTrue(light.getState() instanceof OffState);
    }

    @Test
    public void testUpdateWithDifferentEventType() {
        SensorEvent event = new SensorEvent("SENSOR_001", "TEMPERATURE", "HIGH");
        controller.update(event);
        assertTrue(light.getState() instanceof OffState);
    }

    @Test
    public void testUpdateWithDifferentSensor() {
        SensorEvent event = new SensorEvent("SENSOR_002", "MOTION", "DETECTED");
        controller.update(event);
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testMultipleUpdates() {
        SensorEvent event1 = new SensorEvent("SENSOR_001", "MOTION", "DETECTED");
        SensorEvent event2 = new SensorEvent("SENSOR_001", "MOTION", "STOPPED");

        controller.update(event1);
        assertTrue(light.getState() instanceof OnState);

        controller.update(event2);
        assertTrue(light.getState() instanceof OffState);
    }
}