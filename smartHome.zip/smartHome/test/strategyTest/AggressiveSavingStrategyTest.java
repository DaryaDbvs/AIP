package strategyTest;


import entity.Light;
import entity.Thermostat;
import state.OffState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import strategy.AggressiveSavingStrategy;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import static org.testng.Assert.*;

public class AggressiveSavingStrategyTest {

    private AggressiveSavingStrategy strategy;
    private Light light;
    private Thermostat thermostat;

    @BeforeMethod
    public void setUp() {
        strategy = new AggressiveSavingStrategy();
        light = new Light("Living Room", 80);
        thermostat = new Thermostat("Main Thermo", 22.5);
    }

    @Test
    public void testApplyWithLight() {
        List<entity.Device> devices = Arrays.asList(light);
        strategy.apply(devices);
        assertTrue(light.getState() instanceof OffState);
    }

    @Test
    public void testApplyWithThermostat() {
        List<entity.Device> devices = Arrays.asList(thermostat);
        strategy.apply(devices);
        assertEquals(thermostat.getTemperature(), 15.0);
    }

    @Test
    public void testApplyWithMixedDevices() {
        List<entity.Device> devices = Arrays.asList(light, thermostat);
        strategy.apply(devices);

        assertTrue(light.getState() instanceof OffState);
        assertEquals(thermostat.getTemperature(), 15.0);
    }

    @Test
    public void testApplyWithEmptyList() {
        List<entity.Device> devices = new ArrayList<>();
        strategy.apply(devices);

    }

    @Test
    public void testLightBrightnessNotChanged() {
        int originalBrightness = light.getBrightness();
        List<entity.Device> devices = Arrays.asList(light);
        strategy.apply(devices);

        assertEquals(light.getBrightness(), originalBrightness);
        assertTrue(light.getState() instanceof OffState);
    }
}