package strategyTest;

import entity.Light;
import entity.Thermostat;
import state.OffState;
import org.testng.annotations.Test;
import strategy.AggressiveSavingStrategy;
import strategy.EnergySavingStrategy;
import strategy.ModerateSavingStrategy;
import strategy.NoSavingStrategy;

import java.util.Arrays;
import java.util.List;
import static org.testng.Assert.*;

public class StrategyIntegrationTest {

    @Test
    public void testSwitchBetweenStrategies() {
        Light light = new Light("Test Light", 80);
        Thermostat thermostat = new Thermostat("Test Thermo", 22.5);
        List<entity.Device> devices = Arrays.asList(light, thermostat);

        EnergySavingStrategy moderate = new ModerateSavingStrategy();
        moderate.apply(devices);
        assertEquals(light.getBrightness(), 30);
        assertEquals(thermostat.getTemperature(), 18.0);

        EnergySavingStrategy aggressive = new AggressiveSavingStrategy();
        aggressive.apply(devices);
        assertTrue(light.getState() instanceof OffState);
        assertEquals(thermostat.getTemperature(), 15.0);


        EnergySavingStrategy none = new NoSavingStrategy();
        none.apply(devices);

        assertTrue(light.getState() instanceof OffState);
        assertEquals(thermostat.getTemperature(), 15.0);
    }

    @Test
    public void testStrategyWithDifferentDevices() {
        Light light1 = new Light("Light 1", 90);
        Light light2 = new Light("Light 2", 70);
        Thermostat thermo1 = new Thermostat("Thermo 1", 23.0);

        List<entity.Device> devices = Arrays.asList(light1, light2, thermo1);

        EnergySavingStrategy aggressive = new AggressiveSavingStrategy();
        aggressive.apply(devices);

        assertTrue(light1.getState() instanceof OffState);
        assertTrue(light2.getState() instanceof OffState);
        assertEquals(thermo1.getTemperature(), 15.0);
    }
}