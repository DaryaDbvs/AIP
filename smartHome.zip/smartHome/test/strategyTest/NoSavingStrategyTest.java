package strategyTest;


import entity.Light;
import entity.Thermostat;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import strategy.NoSavingStrategy;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import static org.testng.Assert.*;

public class NoSavingStrategyTest {

    private NoSavingStrategy strategy;
    private Light light;
    private Thermostat thermostat;

    @BeforeMethod
    public void setUp() {
        strategy = new NoSavingStrategy();
        light = new Light("Living Room", 80);
        thermostat = new Thermostat("Main Thermo", 22.5);
    }

    @Test
    public void testApplyWithLight() {
        int originalBrightness = light.getBrightness();
        List<entity.Device> devices = Arrays.asList(light);
        strategy.apply(devices);

        assertEquals(light.getBrightness(), originalBrightness);
    }

    @Test
    public void testApplyWithThermostat() {
        double originalTemp = thermostat.getTemperature();
        List<entity.Device> devices = Arrays.asList(thermostat);
        strategy.apply(devices);

        assertEquals(thermostat.getTemperature(), originalTemp);
    }

    @Test
    public void testApplyWithMixedDevices() {
        int originalBrightness = light.getBrightness();
        double originalTemp = thermostat.getTemperature();

        List<entity.Device> devices = Arrays.asList(light, thermostat);
        strategy.apply(devices);

        assertEquals(light.getBrightness(), originalBrightness);
        assertEquals(thermostat.getTemperature(), originalTemp);
    }

    @Test
    public void testApplyWithEmptyList() {
        List<entity.Device> devices = new ArrayList<>();
        strategy.apply(devices);
    }
}
