package commandTest;

import command.TurnOnCommand;
import entity.Light;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class TurnOnCommandTest {

    private Light light;
    private TurnOnCommand command;

    @BeforeMethod
    public void setUp() {
        light = new Light("Test Light", 50);
        command = new TurnOnCommand(light);
    }

    @Test
    public void testExecute() {
        command.execute();
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testUndo() {
        command.undo();
        // Undo just logs, no state changes
        assertNotNull(light);
    }

    @Test
    public void testExecuteMultipleTimes() {
        command.execute();
        command.execute();
        assertTrue(light.getState() instanceof OnState);
    }
}