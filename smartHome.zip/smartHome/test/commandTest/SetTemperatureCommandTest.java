package commandTest;

import command.SetTemperatureCommand;
import entity.Thermostat;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class SetTemperatureCommandTest {

    private Thermostat thermostat;
    private SetTemperatureCommand command;

    @BeforeMethod
    public void setUp() {
        thermostat = new Thermostat("Test Thermostat", 22.5);
        command = new SetTemperatureCommand(thermostat, 18.0);
    }

    @Test
    public void testExecute() {
        command.execute();
        assertEquals(thermostat.getTemperature(), 18.0);
    }

    @Test
    public void testUndo() {
        command.execute();
        command.undo();
        assertEquals(thermostat.getTemperature(), 22.5);
    }

    @Test
    public void testUndoWithoutExecute() {
        command.undo();
        assertEquals(thermostat.getTemperature(), 22.5,
                "Undo without execute should not change temperature");
    }

    @Test
    public void testExecuteWithSameTemperature() {
        SetTemperatureCommand sameTempCommand = new SetTemperatureCommand(thermostat, 22.5);
        sameTempCommand.execute();
        assertEquals(thermostat.getTemperature(), 22.5);
    }

    @Test
    public void testMultipleUndo() {
        command.execute();
        command.undo();
        command.undo(); // Second undo should not cause issues
        assertEquals(thermostat.getTemperature(), 22.5);
    }

    @Test
    public void testExecuteThenExecuteAgain() {
        command.execute();
        assertEquals(thermostat.getTemperature(), 18.0);

        // Create new command to set different temperature
        SetTemperatureCommand secondCommand = new SetTemperatureCommand(thermostat, 20.0);
        secondCommand.execute();
        assertEquals(thermostat.getTemperature(), 20.0);

        secondCommand.undo();
        assertEquals(thermostat.getTemperature(), 18.0);
    }
}