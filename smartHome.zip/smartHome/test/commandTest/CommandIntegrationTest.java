package commandTest;


import command.Command;
import command.SetTemperatureCommand;
import command.TurnOffCommand;
import command.TurnOnCommand;
import entity.Light;
import entity.Thermostat;
import state.OnState;
import state.OffState;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;
import static org.testng.Assert.*;

public class CommandIntegrationTest {

    @Test
    public void testMultipleCommands() {
        Light light = new Light("Living Room", 80);
        Thermostat thermostat = new Thermostat("Main Thermo", 22.5);

        List<Command> commands = new ArrayList<>();
        commands.add(new TurnOnCommand(light));
        commands.add(new SetTemperatureCommand(thermostat, 20.0));

        for (Command cmd : commands) {
            cmd.execute();
        }

        assertTrue(light.getState() instanceof OnState);
        assertEquals(thermostat.getTemperature(), 20.0);
    }

    @Test
    public void testCommandUndoSequence() {
        Light light = new Light("Test Light", 50);
        TurnOnCommand turnOn = new TurnOnCommand(light);
        TurnOffCommand turnOff = new TurnOffCommand(light);

        turnOn.execute();
        assertTrue(light.getState() instanceof OnState);

        turnOff.execute();
        assertTrue(light.getState() instanceof OffState);

        turnOff.undo();
        turnOn.undo();
    }
}