package commandTest;


import command.TurnOffCommand;
import entity.Light;
import state.OffState;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class TurnOffCommandTest {

    private Light light;
    private TurnOffCommand command;

    @BeforeMethod
    public void setUp() {
        light = new Light("Test Light", 50);
        light.setState(new OnState());
        command = new TurnOffCommand(light);
    }

    @Test
    public void testExecute() {
        command.execute();
        assertTrue(light.getState() instanceof OffState);
    }

    @Test
    public void testUndo() {
        command.undo();
        assertNotNull(light);
    }

    @Test
    public void testExecuteWhenAlreadyOff() {
        light.setState(new OffState());
        command.execute();
        assertTrue(light.getState() instanceof OffState);
    }
}