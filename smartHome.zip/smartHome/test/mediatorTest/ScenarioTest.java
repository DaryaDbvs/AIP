package mediatorTest;


import command.SetTemperatureCommand;
import command.TurnOffCommand;
import command.TurnOnCommand;
import entity.Light;
import entity.Thermostat;
import mediator.Scenario;
import state.OffState;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class ScenarioTest {

    private Scenario scenario;
    private Light light;
    private Thermostat thermostat;

    @BeforeMethod
    public void setUp() {
        scenario = new Scenario("Morning Routine");
        light = new Light("Living Room", 80);
        thermostat = new Thermostat("Main Thermo", 22.5);
    }

    @Test
    public void testScenarioCreation() {
        assertNotNull(scenario);
    }

    @Test
    public void testAddCommand() {
        scenario.addCommand(new TurnOnCommand(light));
        scenario.addCommand(new SetTemperatureCommand(thermostat, 21.0));
        scenario.execute();

        assertTrue(light.getState() instanceof OnState);
        assertEquals(thermostat.getTemperature(), 21.0);
    }

    @Test
    public void testExecuteEmptyScenario() {
        scenario.execute();
        // Should not throw exception
    }

    @Test
    public void testExecuteWithSingleCommand() {
        scenario.addCommand(new TurnOnCommand(light));
        scenario.execute();
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testExecuteWithMultipleCommands() {
        scenario.addCommand(new TurnOnCommand(light));
        scenario.addCommand(new SetTemperatureCommand(thermostat, 20.0));
        scenario.addCommand(new TurnOffCommand(light));
        scenario.execute();

        assertTrue(light.getState() instanceof OffState);
        assertEquals(thermostat.getTemperature(), 20.0);
    }

    @Test
    public void testMorningScenario() {
        Scenario morning = new Scenario("Утро");
        morning.addCommand(new TurnOnCommand(light));
        morning.addCommand(new SetTemperatureCommand(thermostat, 22.0));
        morning.execute();

        assertTrue(light.getState() instanceof OnState);
        assertEquals(thermostat.getTemperature(), 22.0);
    }

    @Test
    public void testNightScenario() {
        Scenario night = new Scenario("Сон");
        night.addCommand(new TurnOffCommand(light));
        night.addCommand(new SetTemperatureCommand(thermostat, 18.0));
        night.execute();

        assertTrue(light.getState() instanceof OffState);
        assertEquals(thermostat.getTemperature(), 18.0);
    }
}