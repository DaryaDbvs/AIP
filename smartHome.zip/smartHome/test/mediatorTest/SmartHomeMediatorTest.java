package mediatorTest;


import command.TurnOnCommand;
import entity.Light;
import mediator.SmartHomeMediator;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class SmartHomeMediatorTest {

    private SmartHomeMediator mediator;
    private Light light;

    @BeforeMethod
    public void setUp() {
        mediator = new SmartHomeMediator();
        light = new Light("Test Light", 75);
    }

    @Test
    public void testRegisterDevice() {
        mediator.registerDevice(light);
        // No exception means success
    }

    @Test
    public void testExecuteScenario() {
        mediator.registerDevice(light);
        TurnOnCommand turnOn = new TurnOnCommand(light);
        mediator.executeScenario(turnOn);
        assertTrue(light.getState() instanceof OnState);
    }

    @Test
    public void testMultipleDevicesRegistration() {
        Light light2 = new Light("Second Light", 50);
        mediator.registerDevice(light);
        mediator.registerDevice(light2);
        // No exception means success
    }

    @Test
    public void testExecuteScenarioWithoutDevices() {
        TurnOnCommand turnOn = new TurnOnCommand(light);
        mediator.executeScenario(turnOn);
        assertTrue(light.getState() instanceof OnState);
    }
}
