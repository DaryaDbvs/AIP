package stateTest;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import state.MaintenanceState;

import static org.testng.Assert.*;

public class MaintenanceStateTest {

    private MaintenanceState state;

    @BeforeMethod
    public void setUp() {
        state = new MaintenanceState();
    }

    @Test
    public void testGetStateName() {
        assertEquals(state.getStateName(), "MAINTENANCE");
    }

    @Test
    public void testOn() {
        state.on(); // Should not throw exception
    }

    @Test
    public void testOff() {
        state.off(); // Should not throw exception
    }

    @Test
    public void testError() {
        state.error(); // Should not throw exception
    }

    @Test
    public void testMaintenance() {
        state.maintenance(); // Should not throw exception
    }
}