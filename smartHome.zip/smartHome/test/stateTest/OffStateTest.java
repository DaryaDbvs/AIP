package stateTest;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import state.OffState;

import static org.testng.Assert.*;

public class OffStateTest {

    private OffState state;

    @BeforeMethod
    public void setUp() {
        state = new OffState();
    }

    @Test
    public void testGetStateName() {
        assertEquals(state.getStateName(), "OFF");
    }

    @Test
    public void testOn() {
        state.on(); // Should not throw exception
    }

    @Test
    public void testOff() {
        state.off(); // Should not throw exception
    }

    @Test
    public void testError() {
        state.error(); // Should not throw exception
    }

    @Test
    public void testMaintenance() {
        state.maintenance(); // Should not throw exception
    }
}