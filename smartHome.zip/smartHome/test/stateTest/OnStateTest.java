package stateTest;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import state.OnState;

import static org.testng.Assert.*;

public class OnStateTest {

    private OnState state;

    @BeforeMethod
    public void setUp() {
        state = new OnState();
    }

    @Test
    public void testGetStateName() {
        assertEquals(state.getStateName(), "ON");
    }

    @Test
    public void testOn() {
        state.on(); // Should not throw exception
    }

    @Test
    public void testOff() {
        state.off(); // Should not throw exception
    }

    @Test
    public void testError() {
        state.error(); // Should not throw exception
    }

    @Test
    public void testMaintenance() {
        state.maintenance(); // Should not throw exception
    }
}