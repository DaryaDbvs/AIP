package validatorTest;


import entity.Light;
import state.OffState;
import state.OnState;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import validator.ResultValidator;
import validator.ValidationResult;

import static org.testng.Assert.*;

public class ResultValidatorTest {

    private ResultValidator validator;
    private Light light;

    @BeforeMethod
    public void setUp() {
        validator = new ResultValidator();
        light = new Light("Test Light", 50);
    }

    @Test
    public void testValidateDeviceStateValid() {
        light.setState(new OnState());
        ValidationResult result = validator.validateDeviceState(light);
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testValidateDeviceStateNull() {
        // Instead of setting null state (which throws exception),
        // we create a device with a null state using reflection or
        // we test the validator with a device that has null state
        // Но легче проверить, что валидатор обрабатывает null корректно

        // Создаём устройство через рефлексию с null состоянием
        try {
            java.lang.reflect.Field stateField = Light.class.getSuperclass().getDeclaredField("state");
            stateField.setAccessible(true);
            stateField.set(light, null);

            ValidationResult result = validator.validateDeviceState(light);
            assertFalse(result.isValid());
            assertEquals(result.getErrorMessage(), "Device has no state");
        } catch (Exception e) {
            fail("Could not set state via reflection: " + e.getMessage());
        }
    }

    @Test
    public void testValidateDeviceStateWithOffState() {
        light.setState(new OffState());
        ValidationResult result = validator.validateDeviceState(light);
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateDeviceStateWithOnState() {
        light.setState(new OnState());
        ValidationResult result = validator.validateDeviceState(light);
        assertTrue(result.isValid());
    }
}