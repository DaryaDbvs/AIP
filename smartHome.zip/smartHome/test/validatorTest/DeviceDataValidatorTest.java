package validatorTest;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import validator.DeviceDataValidator;
import validator.ValidationResult;

import static org.testng.Assert.*;

public class DeviceDataValidatorTest {

    private DeviceDataValidator validator;

    @BeforeMethod
    public void setUp() {
        validator = new DeviceDataValidator();
    }

    // Light validation tests
    @Test
    public void testValidateLightValid() {
        ValidationResult result = validator.validateLight("Living Room", "75");
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testValidateLightEmptyName() {
        ValidationResult result = validator.validateLight("", "75");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid light name");
    }

    @Test
    public void testValidateLightNullName() {
        ValidationResult result = validator.validateLight(null, "75");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid light name");
    }

    @Test
    public void testValidateLightNameWithSpacesOnly() {
        ValidationResult result = validator.validateLight("   ", "75");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid light name");
    }

    @Test
    public void testValidateLightInvalidBrightnessFormat() {
        ValidationResult result = validator.validateLight("Living Room", "invalid");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid brightness number");
    }

    @Test
    public void testValidateLightBrightnessBelowZero() {
        ValidationResult result = validator.validateLight("Living Room", "-10");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Brightness must be 0-100");
    }

    @Test
    public void testValidateLightBrightnessAbove100() {
        ValidationResult result = validator.validateLight("Living Room", "150");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Brightness must be 0-100");
    }

    @Test
    public void testValidateLightBrightnessZero() {
        ValidationResult result = validator.validateLight("Living Room", "0");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateLightBrightness100() {
        ValidationResult result = validator.validateLight("Living Room", "100");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateLightBrightnessDecimal() {
        ValidationResult result = validator.validateLight("Living Room", "75.5");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid brightness number");
    }

    // Thermostat validation tests
    @Test
    public void testValidateThermostatValid() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "22.5");
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testValidateThermostatEmptyName() {
        ValidationResult result = validator.validateThermostat("", "22.5");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid thermostat name");
    }

    @Test
    public void testValidateThermostatNullName() {
        ValidationResult result = validator.validateThermostat(null, "22.5");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid thermostat name");
    }

    @Test
    public void testValidateThermostatInvalidTemperatureFormat() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "invalid");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid temperature number");
    }

    @Test
    public void testValidateThermostatTemperatureBelowZero() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "-5");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Temperature must be 0-40°C");
    }

    @Test
    public void testValidateThermostatTemperatureAbove40() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "45");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Temperature must be 0-40°C");
    }

    @Test
    public void testValidateThermostatTemperatureZero() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "0");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateThermostatTemperature40() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "40");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateThermostatTemperatureWithDecimal() {
        ValidationResult result = validator.validateThermostat("Main Thermo", "22.5");
        assertTrue(result.isValid());
    }

    // Lock validation tests
    @Test
    public void testValidateLockValidTrue() {
        ValidationResult result = validator.validateLock("Front Door", "true");
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testValidateLockValidFalse() {
        ValidationResult result = validator.validateLock("Front Door", "false");
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testValidateLockValidTrueUpperCase() {
        ValidationResult result = validator.validateLock("Front Door", "TRUE");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateLockValidFalseUpperCase() {
        ValidationResult result = validator.validateLock("Front Door", "FALSE");
        assertTrue(result.isValid());
    }

    @Test
    public void testValidateLockEmptyName() {
        ValidationResult result = validator.validateLock("", "true");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid lock name");
    }

    @Test
    public void testValidateLockNullName() {
        ValidationResult result = validator.validateLock(null, "true");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Invalid lock name");
    }

    @Test
    public void testValidateLockInvalidValue() {
        ValidationResult result = validator.validateLock("Front Door", "maybe");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Locked must be true/false");
    }

    @Test
    public void testValidateLockInvalidValueNumber() {
        ValidationResult result = validator.validateLock("Front Door", "1");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Locked must be true/false");
    }
}