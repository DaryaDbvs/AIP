package validatorTest;


import org.testng.annotations.Test;
import validator.ValidationResult;

import static org.testng.Assert.*;

public class ValidationResultTest {

    @Test
    public void testValidResult() {
        ValidationResult result = new ValidationResult(true, null);
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void testInvalidResultWithMessage() {
        ValidationResult result = new ValidationResult(false, "Error message");
        assertFalse(result.isValid());
        assertEquals(result.getErrorMessage(), "Error message");
    }

    @Test
    public void testInvalidResultWithoutMessage() {
        ValidationResult result = new ValidationResult(false, null);
        assertFalse(result.isValid());
        assertNull(result.getErrorMessage());
    }
}